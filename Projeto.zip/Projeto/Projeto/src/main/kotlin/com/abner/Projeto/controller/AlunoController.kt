package com.abner.Projeto.controller

import com.abner.Projeto.dto.AlunoComCursosDTO
import com.abner.Projeto.entity.Aluno
import com.abner.Projeto.entity.Curso
import com.abner.Projeto.repository.AlunoCursoRepositorio
import com.abner.Projeto.repository.AlunoRepositorio
import com.abner.Projeto.repository.CursoRepositorio
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/alunos")
class AlunoController(
    private val alunoRepositorio: AlunoRepositorio,
    private val alunoCursoRepositorio: AlunoCursoRepositorio,
    private val cursoRepositorio: CursoRepositorio
) {

    @GetMapping
    fun listarAlunos(): List<Aluno> = alunoRepositorio.findAll()

    @GetMapping("/{id}")
    fun buscarPorId(@PathVariable id: Long): ResponseEntity<AlunoComCursosDTO> {
        val aluno = alunoRepositorio.findById(id).orElse(null)
            ?: return ResponseEntity.notFound().build()

        val cursoIds = alunoCursoRepositorio.findByAlunoId(id).map { it.cursoId }
        val cursos: List<Curso> = cursoRepositorio.findAllById(cursoIds)

        val dto = AlunoComCursosDTO.from(aluno, cursos)

        return ResponseEntity.ok(dto)
    }

    @PostMapping
    fun salvarAluno(@RequestBody aluno: Aluno): Aluno = alunoRepositorio.save(aluno)

    @PutMapping("/{id}")
    fun atualizarAluno(@PathVariable id: Long, @RequestBody alunoAtualizado: Aluno): ResponseEntity<Aluno> {
        val alunoExistente = alunoRepositorio.findById(id).orElse(null)
            ?: return ResponseEntity.notFound().build()

        val alunoSalvo = alunoExistente.copy(
            nome = alunoAtualizado.nome,
            matricula = alunoAtualizado.matricula
        )

        return ResponseEntity.ok(alunoRepositorio.save(alunoSalvo))
    }

    @DeleteMapping("/{id}")
    fun deletarAluno(@PathVariable id: Long): ResponseEntity<Void> {
        if (!alunoRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build()
        }
        alunoRepositorio.deleteById(id)
        return ResponseEntity.noContent().build()
    }
}
