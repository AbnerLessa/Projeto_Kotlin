package com.abner.Projeto.entity

import jakarta.persistence.*

@Entity
@Table(name = "aluno_curso")
data class AlunoCurso(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,

    val alunoId: Long,
    val cursoId: Long
)