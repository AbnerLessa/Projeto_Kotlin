package com.abner.Projeto.entity

import jakarta.persistence.*

@Entity
@Table(name = "cursos")
data class Curso(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,

    @Column(nullable = false)
    val nome: String,

    @Column(nullable = false)
    val duracao: Int // em semestres
)
