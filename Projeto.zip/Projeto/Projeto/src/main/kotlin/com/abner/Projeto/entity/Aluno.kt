package com.abner.Projeto.entity

import jakarta.persistence.*

@Entity
@Table(name = "alunos")
data class Aluno(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,

    @Column(nullable = false)
    val nome: String,

    @Column(nullable = false, unique = true)
    val matricula: String
)