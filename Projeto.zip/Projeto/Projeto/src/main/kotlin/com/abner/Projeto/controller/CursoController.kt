package com.abner.Projeto.controller

import com.abner.Projeto.entity.Curso
import com.abner.Projeto.repository.CursoRepositorio
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/cursos")
class CursoController(
    private val cursoRepositorio: CursoRepositorio
) {

    // GET: Lista todos os cursos
    @GetMapping
    fun listarCursos(): List<Curso> = cursoRepositorio.findAll()

    // GET: Busca curso por ID
    @GetMapping("/{id}")
    fun buscarPorId(@PathVariable id: Long): ResponseEntity<Curso> {
        val curso = cursoRepositorio.findById(id)
        return if (curso.isPresent) ResponseEntity.ok(curso.get())
        else ResponseEntity.notFound().build()
    }

    // POST: Cadastra novo curso
    @PostMapping
    fun salvarCurso(@RequestBody curso: Curso): Curso =
        cursoRepositorio.save(curso)

    // PUT: Atualiza curso
    @PutMapping("/{id}")
    fun atualizarCurso(@PathVariable id: Long, @RequestBody cursoAtualizado: Curso): ResponseEntity<Curso> {
        val cursoExistente = cursoRepositorio.findById(id).orElse(null)
            ?: return ResponseEntity.notFound().build()

        val cursoSalvo = cursoExistente.copy(
            nome = cursoAtualizado.nome,
            duracao = cursoAtualizado.duracao
        )

        return ResponseEntity.ok(cursoRepositorio.save(cursoSalvo))
    }

    // DELETE: Remove curso
    @DeleteMapping("/{id}")
    fun deletarCurso(@PathVariable id: Long): ResponseEntity<Void> {
        if (!cursoRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build()
        }
        cursoRepositorio.deleteById(id)
        return ResponseEntity.noContent().build()
    }
}
