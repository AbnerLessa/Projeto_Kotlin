package com.abner.Projeto.controller

import com.abner.Projeto.entity.AlunoCurso
import com.abner.Projeto.repository.AlunoCursoRepositorio
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/aluno-curso")
class AlunoCursoController(
    private val alunoCursoRepositorio: AlunoCursoRepositorio
) {

    @GetMapping
    fun listarTodos(): List<AlunoCurso> = alunoCursoRepositorio.findAll()

    @PostMapping("/vincular")
    fun vincularCursosAoAluno(
        @RequestParam alunoId: Long,
        @RequestBody cursoIds: List<Long>
    ): ResponseEntity<List<AlunoCurso>> {
        val relacoes = cursoIds.map { cursoId ->
            AlunoCurso(alunoId = alunoId, cursoId = cursoId)
        }
        val salvos = alunoCursoRepositorio.saveAll(relacoes)
        return ResponseEntity.ok(salvos)
    }

    @PutMapping("/atualizar/{alunoId}")
    fun atualizarCursosDoAluno(
        @PathVariable alunoId: Long,
        @RequestBody novosCursos: List<Long>
    ): ResponseEntity<List<AlunoCurso>> {
        val antigos = alunoCursoRepositorio.findByAlunoId(alunoId)
        alunoCursoRepositorio.deleteAll(antigos)

        val novosVinculos = novosCursos.map { cursoId ->
            AlunoCurso(alunoId = alunoId, cursoId = cursoId)
        }
        val salvos = alunoCursoRepositorio.saveAll(novosVinculos)
        return ResponseEntity.ok(salvos)
    }

    @DeleteMapping("/{id}")
    fun deletarRelacao(@PathVariable id: Long): ResponseEntity<Void> {
        if (!alunoCursoRepositorio.existsById(id)) {
            return ResponseEntity.notFound().build()
        }
        alunoCursoRepositorio.deleteById(id)
        return ResponseEntity.noContent().build()
    }

    @DeleteMapping("/remover-por-aluno/{alunoId}")
    fun removerPorAluno(@PathVariable alunoId: Long): ResponseEntity<Void> {
        val relacoes = alunoCursoRepositorio.findByAlunoId(alunoId)
        if (relacoes.isEmpty()) {
            return ResponseEntity.notFound().build()
        }
        alunoCursoRepositorio.deleteAll(relacoes)
        return ResponseEntity.noContent().build()
    }
    @DeleteMapping("/por-aluno-e-curso")
    fun deletarCursoEspecificoDoAluno(
        @RequestParam alunoId: Long,
        @RequestParam cursoId: Long
    ): ResponseEntity<Void> {
        // Busca todos os vínculos do aluno
        val relacoes = alunoCursoRepositorio.findByAlunoId(alunoId)

        // Encontra a relação específica com o curso
        val relacao = relacoes.find { it.cursoId == cursoId }

        if (relacao == null) {
            return ResponseEntity.notFound().build()
        }

        // Remove a relação
        alunoCursoRepositorio.delete(relacao)
        return ResponseEntity.noContent().build()
    }
}