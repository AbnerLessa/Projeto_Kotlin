package com.abner.Projeto.repository

import com.abner.Projeto.entity.Curso
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface CursoRepositorio : JpaRepository<Curso, Long>
