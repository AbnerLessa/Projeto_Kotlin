package com.abner.Projeto.repository

import com.abner.Projeto.entity.AlunoCurso
import com.abner.Projeto.entity.Curso
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository

@Repository
interface AlunoCursoRepositorio : JpaRepository<AlunoCurso, Long> {

    fun findByAlunoId(alunoId: Long): List<AlunoCurso>

    @Query(
        value = """
            SELECT c.* FROM cursos c
            INNER JOIN aluno_curso ac ON c.id = ac.curso_id
            WHERE ac.aluno_id = :alunoId
        """,
        nativeQuery = true
    )
    fun buscarCursosDoAluno(@Param("alunoId") alunoId: Long): List<Curso>
}