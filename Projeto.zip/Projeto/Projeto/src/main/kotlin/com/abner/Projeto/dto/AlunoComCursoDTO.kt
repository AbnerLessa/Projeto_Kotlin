package com.abner.Projeto.dto

import com.abner.Projeto.entity.Aluno
import com.abner.Projeto.entity.Curso

// DTO que será retornado com informações do aluno e cursos vinculados

data class AlunoComCursosDTO(
    val id: Long,
    val nome: String?,
    val matricula: String?,
    val cursos: List<Curso>
) {
    companion object {
        fun from(aluno: Aluno, cursos: List<Curso>): AlunoComCursosDTO {
            return AlunoComCursosDTO(
                id = aluno.id,
                nome = aluno.nome,
                matricula = aluno.matricula,
                cursos = cursos
            )
        }
    }
}
